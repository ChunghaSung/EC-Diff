From SCT bench in ISSTA 2014 paper
