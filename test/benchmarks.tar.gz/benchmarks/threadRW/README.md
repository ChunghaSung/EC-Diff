From ISSTA 2015
/* Testcase from Threader's distribution. For details see:
http://www.model.in.tum.de/~popeea/research/threader

This file is adapted from the example introduced in the paper:
Thread-Modular Verification for Shared-Memory Programs 
by Cormac Flanagan, Stephen Freund, Shaz Qadeer.
 */

