# only rank1 has the result.
# Since total number of read from is less than 2, higher rank cannot find any differences.
