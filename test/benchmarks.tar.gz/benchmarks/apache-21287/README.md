Got it from ISSTA 2014 paper  
Implementation of an atomicity violation found in Apache 2.0.48, bug report #21287
 
 Source: http://web.eecs.umich.edu/~jieyu/bugs/apache-21287.html
 
  Bug Report: http://issues.apache.org/bugzilla/show_bug.cgi?id=21287
 
  Apache Source: http://web.eecs.umich.edu/~jieyu/bugs/apache-21287/httpd-2.0.48.tar.gz
 
  Note: A copy of the apache source is hosted on the git repo and I (markus)
  should have a local copy as well.
