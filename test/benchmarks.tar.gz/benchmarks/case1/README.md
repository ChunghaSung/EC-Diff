Test case for lock acquisition and relase.
