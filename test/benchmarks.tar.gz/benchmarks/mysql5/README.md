From ISSTA 2014 paper
