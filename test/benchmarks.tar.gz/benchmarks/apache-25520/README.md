 Example of bug #25520 in Apache 2.0.48 (a data race/atomicity violation)

 Source: http://web.eecs.umich.edu/~jieyu/bugs/apache-25520.html

 Bug Report: https://issues.apache.org/bugzilla/show_bug.cgi?id=25520

 See README.md or `html/index.html` for more information 

