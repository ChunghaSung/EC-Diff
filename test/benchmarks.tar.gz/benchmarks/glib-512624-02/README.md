From ISSTA 2014

 Source: https://bugzilla.gnome.org/show_bug.cgi?id=512624

 Data race and atomicity violoation found in glib.

 Involves the use to unatomic increment/decrements in multiple threads
