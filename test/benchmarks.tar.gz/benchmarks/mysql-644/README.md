From ISSTA 2015

\file

Source: http://web.eecs.umich.edu/~jieyu/bugs/mysql-644.html

Much simplified version of a bug found in MySQL. See README.md for more
information.


