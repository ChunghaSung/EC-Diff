Test case for conditional wait and conditional signal between threads
