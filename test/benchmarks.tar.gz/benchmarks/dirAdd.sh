#!/bin/bash

#source ../testDir-large.sh
#
for name in ${TESTDIRS}
do
cd $name


#cp results/check-rank1-after-solve.out expected/check-rank1-solve.expected
#cp results/p1-p2-rank1-after-solve.out expected/p1-p2-rank1-solve.expected
#cp results/p2-p1-rank1-after-solve.out expected/p2-p1-rank1-solve.expected

#cp results/check-rank2-after-solve.out expected/check-rank2-solve.expected
#cp results/p1-p2-rank2-after-solve.out expected/p1-p2-rank2-solve.expected
#cp results/p2-p1-rank2-after-solve.out expected/p2-p1-rank2-solve.expected


cd ..

done
