#include <pthread.h>
pthread_cond_t cond2 = PTHREAD_COND_INITIALIZER;
int cond2_bool = 0;
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond1 = PTHREAD_COND_INITIALIZER;
int cond1_bool = 0;
pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond0 = PTHREAD_COND_INITIALIZER;
int cond0_bool = 0;
pthread_mutex_t mutex0 = PTHREAD_MUTEX_INITIALIZER;

//#define assume(e) __VERIFIER_assume(e)
//#define assert(e) { if(!(e)) { ERROR: goto ERROR; (void)0; } }

void nop1() {}

volatile unsigned int count_SHARED = 0; //shared
int c_SHARED;
//_Bool MTX = 0; //shared mutex
//_thread Bool COND = 0; //condition variables become local flag indicating whether the thread was signaled

/*
void __VERIFIER_atomic_acquire()
{
    assume(MTX==0);
    MTX = 1;
}

void __VERIFIER_atomic_release()
{
    assume(MTX==1);
    MTX = 0;
}
*/

/*
#define cnd_wait(c,m){ \
    __VERIFIER_atomic_begin(); \
    assume(c); \
    c = 0; \
    __VERIFIER_atomic_end(); }

#define cnd_broadcast(c) (c = 1) //BP must be post-processed manually by changing "b*_COND := 1" to "b*_COND$ := 1"
*/


void* thr1(void* arg){

    nop1();
    cond0_bool = 1;
    nop1();

    nop1();
    cond1_bool = 1;
    nop1();

    nop1();
    if (!cond2_bool) {
        nop1();
    }
    nop1();

    count_SHARED++;
    nop1();

    nop1();

    if (count_SHARED == 3) { 
        //cnd_broadcast(COND); 
        c_SHARED = 1;
        count_SHARED = 0; 
        return 0;
    }
    c_SHARED = 0;
    //cnd_wait(COND,MTX);
    //assert(0);
    return 0;

} 

void* thr2(void* arg){

    nop1();
    if (!cond0_bool) {
        nop1();
    }
    nop1();

    count_SHARED++;
    nop1();
    cond2_bool = 1;
    nop1();

    if (count_SHARED == 3) { 
        //cnd_broadcast(COND); 
        c_SHARED = 1;
        count_SHARED = 0; 
        return 0;
    }
    nop1();

    c_SHARED = 0;
    //assert(0);

    return 0;
} 

void* thr3 (void* arg){
    nop1();
    if (!cond1_bool) {
        nop1();
    }
    nop1();

    count_SHARED++;
    if (count_SHARED == 3) { 
        //cnd_broadcast(COND); 
        c_SHARED = 1;
        count_SHARED = 0; 
        return 0;
    }
    //cnd_wait(COND,MTX);
    c_SHARED = 0;
    //assert(0);

    return 0;
} 

int main(){
    pthread_t t1, t2, t3;

    //while(1) { pthread_create(&t, 0, thr1, 0); }
    pthread_create(&t1, NULL, thr1, NULL);
    pthread_create(&t2, NULL, thr2, NULL);
    pthread_create(&t3, NULL, thr3, NULL);

    return 0;
}
