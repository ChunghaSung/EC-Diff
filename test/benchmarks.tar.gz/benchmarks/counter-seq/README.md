 ISSTA 2014 paper

 A sequential counter used in a concurrent setting

 Adapted from Art of Multiprocessor Programming
