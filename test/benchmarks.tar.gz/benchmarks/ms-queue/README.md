From ISSTA 2014 paper
// From: http://pages.cs.wisc.edu/~remzi/OSTEP/threads-locks-usage.pdf
// Page: 10
//
